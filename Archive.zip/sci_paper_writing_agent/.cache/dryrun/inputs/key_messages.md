# Key messages

## Drafted by the model from inputs/results.md: review and edit before planning

- Out-of-sample models based on body physiology predicted the general factor of cognition with moderate accuracy, performing as well as or better than all single and stacked neuroimaging models.
- Among neuroimaging modalities, resting-state functional MRI connectivity was the strongest predictor of the cognitive factor and EEG the weakest, and stacking MRI feature sets yielded only modest gains while adding EEG brought no improvement.
- Lean body composition, body water, and metabolic measures showed the strongest positive associations with predicted cognitive ability, heart rate was negatively associated, and after removing age-related variance, adiposity and blood pressure measures showed weak negative associations.
- Predictive performance and feature associations were largely comparable between males and females, with no sex differences surviving correction for multiple comparisons.
- Neuroimaging measures captured a substantial share of the cognitive variance explained by body physiology, and body physiology together with a composite brain measure accounted for nearly half of the association between age and cognitive ability.
