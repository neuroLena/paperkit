## Principal findings

Dry run: we observed {{F1}} and {{F2}}. <!-- C1 -->

## Comparison with prior work

Dry run: this suggests an interpretation that the real writer will supply [@Conners2001Conners]. <!-- C2 -->

## Limitations

Dry run: this assumes a premise that was not tested. <!-- C3 -->

## Conclusion

Dry run: one possibility is that later work may clarify this. <!-- C4 -->
