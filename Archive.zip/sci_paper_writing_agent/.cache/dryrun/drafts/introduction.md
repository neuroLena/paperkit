## Background

Dry run: we observed {{F1}} and {{F2}}. <!-- C1 -->

## Knowledge gap

Dry run: this suggests an interpretation that the real writer will supply [@Conners2001Conners]. <!-- C2 -->

## Aim

Dry run: this assumes a premise that was not tested. <!-- C3 -->
