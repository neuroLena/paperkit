"""Document ingestion components."""
